<?php
    $database=mysqli_connect("localhost","id17020119_user","i*uH|*u[5F&cE\OM","id17020119_system");
?>